from math import factorial

# function for nCr()
def nCr(n, r):
    result = factorial(n)/(factorial(r) * factorial(n-r))
    return round(result)

num = int(input("Enter the number: "))

def print_pascal_traingle(num):
    # This for loop determines the number of rows.
    for i in range(0, num):
        # This for loop determines the number of spaces.
        # if n = 5, for 1st row it have 4 blank spaces.
        # if n = 4, 2nd row, it should have 3 blank spaces and so on.
        # end="" it will not goes to new line.
        for k in range(0, num-i):
            print(" ", end="")
        # This is used to print the numbers accordingly.
        for j in range(0, i+1):
            print(nCr(i, j), end=" ")
        print()

print_pascal_traingle(num)